﻿# -*- coding: utf-8 -*-
# app.py — Density-based risk (GMM only), robust loader, f-string-safe HTML

import os
import traceback
from typing import List, Dict, Any
from collections import deque

import numpy as np
import pandas as pd
import joblib

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.requests import Request
from fastapi.exception_handlers import http_exception_handler
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from sklearn.preprocessing import StandardScaler
from numpy.linalg import inv

# =========================
# 1) 설정
# =========================
CSV_PATH    = os.environ.get("LISTINGS_CSV", "dataset.csv")
MODEL_PATH  = os.environ.get("RISK_MODEL_PATH", "risk_model.joblib")  # GMM 저장본(래퍼/파이프라인/dict 내부도 허용)
MODEL_FEATS = os.environ.get("MODEL_FEATURES")  # 예: "공시가격/보증금(만원),10년 이상,기준금리,매수우위지수,건축연한"
HIGH_RISK   = int(os.environ.get("HIGH_RISK_IDX", "3"))  # 다른 방식 비교시 사용

# 주소 구성 컬럼(검색용)
COL_ID     = os.environ.get("COL_ID", "NO")
COL_SGG    = os.environ.get("COL_SGG", "시군구")
COL_ROAD   = os.environ.get("COL_ROAD", "도로명")
COL_BEONJI = os.environ.get("COL_BEONJI", "번지")
COL_BLDG   = os.environ.get("COL_BLDG", "건물명")

DEFAULT_FEATURES = [
    "공시가격/보증금(만원)",
    "10년 이상",
    "기준금리",
    "매수우위지수",
    "건축연한",
]

def get_features() -> List[str]:
    if MODEL_FEATS:
        feats = [s.strip() for s in MODEL_FEATS.split(",") if s.strip()]
        if feats:
            return feats
    return DEFAULT_FEATURES

FEATURES = get_features()

# =========================
# 2) CSV 로딩 + 주소필드 구성 + 스케일러 복원
# =========================
def load_csv_any(path: str) -> pd.DataFrame:
    encs = ("utf-8-sig","cp949","euc-kr","utf-16","utf-16le","utf-16be","latin1")
    last = None
    for enc in encs:
        try:
            df = pd.read_csv(path, encoding=enc, sep=None, engine="python")
            print(f"[INFO] CSV loaded with encoding={enc}, shape={df.shape}")
            return df
        except Exception as e:
            last = e
            print(f"[WARN] read_csv({enc}) failed: {e}")
    raise RuntimeError(f"CSV 로드 실패: {last}")

_df = load_csv_any(CSV_PATH)

# 주소 표시 문자열 만들기
for c in (COL_SGG, COL_ROAD, COL_BEONJI, COL_BLDG):
    if c not in _df.columns:
        _df[c] = ""
    _df[c] = _df[c].astype(str).fillna("")
_df["address_disp"] = (
    _df[COL_SGG].str.strip()+" "+
    _df[COL_ROAD].str.strip()+" "+
    _df[COL_BEONJI].str.strip()+" "+
    _df[COL_BLDG].str.strip()
).str.replace(r"\s+"," ", regex=True).str.strip()
_df["__addr_lc"] = _df["address_disp"].str.lower()

if COL_ID not in _df.columns:
    _df[COL_ID] = _df.index.astype(str)

# 스케일러 복원: 서비스 시점에서 데이터셋 전체로 StandardScaler를 재적합
def _to_float_series(s: pd.Series) -> pd.Series:
    return s.map(lambda z: float(str(z).replace(",", "")) if pd.notna(z) else np.nan)

def build_scaler_from_csv(df: pd.DataFrame, features: List[str]) -> StandardScaler:
    missing = [c for c in features if c not in df.columns]
    if missing:
        raise RuntimeError(f"데이터셋에 필요한 피처가 없습니다: {missing}")
    X = pd.DataFrame({c: _to_float_series(df[c]) for c in features})
    X = X.dropna()  # 노트북 맥락: dropna 후 fit_transform
    scaler = StandardScaler().fit(X.values.astype(float))
    print("[INFO] StandardScaler fitted on dataset:", len(X), "rows")
    return scaler

_scaler = build_scaler_from_csv(_df, FEATURES)

# =========================
# 3) 모델 로드 (어떤 저장형식이든 GMM을 찾아 추출)
# =========================
if not os.path.exists(MODEL_PATH):
    raise RuntimeError(f"모델 파일 없음: {MODEL_PATH}")
_base = joblib.load(MODEL_PATH)

def _iter_subobjects(root, max_depth=5, max_nodes=10000):
    """dict/list/tuple/객체.__dict__/Pipeline.steps/named_steps를 너비우선 탐색"""
    q = deque([(root, 0)])
    seen = set()
    n = 0
    while q and n < max_nodes:
        obj, d = q.popleft()
        oid = id(obj)
        if oid in seen:
            continue
        seen.add(oid); n += 1
        yield obj
        if d >= max_depth:
            continue
        try:
            if isinstance(obj, dict):
                for v in obj.values():
                    q.append((v, d+1))
            elif isinstance(obj, (list, tuple)):
                for v in obj:
                    q.append((v, d+1))
            if hasattr(obj, "steps"):         # sklearn Pipeline
                for _, v in getattr(obj, "steps"):
                    q.append((v, d+1))
            if hasattr(obj, "named_steps"):
                for v in getattr(obj, "named_steps").values():
                    q.append((v, d+1))
            if hasattr(obj, "__dict__"):
                for v in obj.__dict__.values():
                    q.append((v, d+1))
        except Exception:
            continue

def _is_gmm(o):
    # GMM은 적어도 predict_proba/score_samples가 있고, 학습된 경우 means_/covariances_/weights_가 있음
    return hasattr(o, "predict_proba") and hasattr(o, "score_samples") and (
        hasattr(o, "means_") and hasattr(o, "covariances_") and hasattr(o, "weights_")
    )

_gmm = None
# 1) 최상위
if _is_gmm(_base):
    _gmm = _base
# 2) 내부 재귀 탐색
if _gmm is None:
    for obj in _iter_subobjects(_base):
        if _is_gmm(obj):
            _gmm = obj
            break
# 3) dict의 흔한 키
if _gmm is None and isinstance(_base, dict):
    for k in ("gmm", "model", "estimator", "best_estimator_"):
        v = _base.get(k)
        if v is not None and _is_gmm(v):
            _gmm = v
            break

if _gmm is None:
    print("[DEBUG] type(base)=", type(_base))
    try:
        print("[DEBUG] base keys/attrs:", list(getattr(_base, "__dict__", {}).keys())[:20]
              if not isinstance(_base, dict) else list(_base.keys())[:20])
    except Exception:
        pass
    raise RuntimeError("risk_model.joblib 내부에서 학습된 GaussianMixture를 찾지 못했습니다.")

print("[INFO] GMM loaded. n_components=", len(_gmm.weights_),
      "cov_type=", getattr(_gmm, "covariance_type", "full"))

# =========================
# 4) 전역 밀도 스케일 (분위수 고정)
# =========================
DENS_P1, DENS_P99 = None, None

def init_density_scale():
    global DENS_P1, DENS_P99
    X_all = pd.DataFrame({c: _to_float_series(_df[c]) for c in FEATURES}).dropna()
    if len(X_all) == 0:
        raise RuntimeError("density 스케일 초기화 실패: FEATURE 열에 유효한 행이 없습니다.")
    Z_all = _scaler.transform(X_all.values.astype(float))
    logprob_all = _gmm.score_samples(Z_all)
    dens_all = np.exp(logprob_all)
    DENS_P1  = float(np.percentile(dens_all, 1))
    DENS_P99 = float(np.percentile(dens_all, 99))
    if not np.isfinite(DENS_P1) or not np.isfinite(DENS_P99) or DENS_P99 <= DENS_P1:
        DENS_P1, DENS_P99 = float(dens_all.min()), float(dens_all.max())
    print(f"[INFO] density scale: p1={DENS_P1:.6g}, p99={DENS_P99:.6g}, n={len(dens_all)}")

init_density_scale()

# =========================
# 5) 스코어 계산 도우미 (밀도 기반 기본)
# =========================
def _ensure_feats_df(row_like_df: pd.DataFrame, features: List[str]) -> pd.DataFrame:
    missing = [c for c in features if c not in row_like_df.columns]
    if missing:
        raise ValueError(f"입력 컬럼 누락: {missing}")
    Xv = row_like_df[features].copy()
    for c in features:
        Xv[c] = _to_float_series(Xv[c])
    if Xv.isna().any().any():
        na_cols = [c for c in features if Xv[c].isna().any()]
        raise ValueError(f"입력에 NaN이 있습니다: {na_cols}")
    return Xv

def _transform(X_df: pd.DataFrame) -> np.ndarray:
    return _scaler.transform(X_df[FEATURES].values.astype(float))

def density_risk(Z: np.ndarray) -> np.ndarray:
    """
    risk = 1 - clip( (dens - p1) / (p99 - p1), 0, 1 )
    (dens = exp(score_samples(Z)), p1/p99는 데이터셋 전체 기반 고정값)
    """
    global DENS_P1, DENS_P99
    if DENS_P1 is None or DENS_P99 is None:
        raise RuntimeError("density 스케일이 초기화되지 않았습니다.")
    logprob = _gmm.score_samples(Z)
    dens = np.exp(logprob)
    denom = (DENS_P99 - DENS_P1) if (DENS_P99 > DENS_P1) else 1.0
    norm = (dens - DENS_P1) / denom
    norm = np.clip(norm, 0.0, 1.0)
    return 1.0 - norm

# (비교용) 여전히 활용하고 싶으면 남겨두는 다른 방식들
def posterior_risk(Z: np.ndarray, high_idx: int = HIGH_RISK) -> np.ndarray:
    post = _gmm.predict_proba(Z)
    return post[:, high_idx]

def mahal_risk(Z: np.ndarray, high_idx: int = HIGH_RISK) -> np.ndarray:
    mu = _gmm.means_[high_idx]
    cov_type = getattr(_gmm, "covariance_type", "full")
    covs = _gmm.covariances_
    diff = Z - mu[None, :]

    if cov_type in ("full", "tied"):
        Sigma = covs if cov_type == "tied" else covs[high_idx]
        Sigma_inv = inv(Sigma)
        d2 = np.einsum("ni,ij,nj->n", diff, Sigma_inv, diff)
    elif cov_type == "diag":
        inv_diag = 1.0 / covs[high_idx]
        d2 = np.sum((diff * diff) * inv_diag[None, :], axis=1)
    elif cov_type == "spherical":
        inv_s = 1.0 / covs[high_idx]
        d2 = np.sum(diff * diff, axis=1) * inv_s
    else:
        raise ValueError(f"Unsupported covariance_type: {cov_type}")

    d2 = np.maximum(d2, 0.0)
    return np.exp(-0.5 * d2)

def mixture_similarity_risk(Z: np.ndarray, beta: float = 1.2, high_idx: int = HIGH_RISK) -> np.ndarray:
    post = _gmm.predict_proba(Z)
    mus  = _gmm.means_
    mu_h = mus[high_idx]
    d    = np.linalg.norm(mus - mu_h[None, :], axis=1)
    w    = np.exp(-beta * (d - d.min()))
    w   /= w.sum()
    return (post * w[None, :]).sum(axis=1)

def hybrid_risk(Z: np.ndarray, beta: float = 1.2, lam: float = 0.4, high_idx: int = HIGH_RISK) -> np.ndarray:
    p_high = posterior_risk(Z, high_idx=high_idx)
    mahal  = mahal_risk(Z, high_idx=high_idx)
    return lam * p_high + (1.0 - lam) * mahal

# =========================
# 6) FastAPI 앱 + 예외 핸들러
# =========================
app = FastAPI(title="Jeonse Fraud Risk (Density-based)", version="1.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

@app.exception_handler(Exception)
async def all_exception_handler(request: Request, exc: Exception):
    tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    return JSONResponse(status_code=500, content={"detail": str(exc), "traceback": tb})

@app.exception_handler(StarletteHTTPException)
async def starlette_exception_handler(request: Request, exc: StarletteHTTPException):
    return await http_exception_handler(request, exc)

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(status_code=422, content={"detail": exc.errors()})

# =========================
# 7) 라우트
# =========================
@app.get("/health")
def health():
    return {
        "ok": True,
        "rows": int(len(_df)),
        "features": FEATURES,
        "gmm": {
            "n_components": int(len(_gmm.weights_)),
            "covariance_type": str(getattr(_gmm, "covariance_type", "full")),
        },
        "density_scale": {"p1": DENS_P1, "p99": DENS_P99},
        "default_method": "density"
    }

@app.get("/", response_class=HTMLResponse)
def index_page():
    # f-string 쓰지 않음! 그대로 리터럴 문자열
    html = """
    <!doctype html>
    <html lang=ko>
    <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <title>전세사기 위험도 예측</title>
      <style>
        :root { --bg:#0b1020; --card:#0f172a; --muted:#94a3b8; --text:#e5e7eb; --acc:#60a5fa; --acc2:#ef4444; }
        html,body { margin:0; padding:0; background:linear-gradient(180deg,#0b1020 0%,#111827 60%,#0f172a 100%); color:var(--text); }
        .wrap { max-width: 1024px; margin: 40px auto; padding: 0 20px; font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto; }
        h1 { font-size: 28px; margin: 0 0 16px 0; letter-spacing:.5px; }
        .subtitle { color: var(--muted); margin-bottom: 24px; }
        .grid { display:grid; gap: 18px; grid-template-columns: 1fr; }
        .card { background: linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.02)); border:1px solid rgba(255,255,255,.08);
                border-radius: 18px; padding: 20px; box-shadow: 0 10px 40px rgba(0,0,0,.25); }
        .row { display:grid; grid-template-columns: 1fr auto; gap: 12px; }
        input { width: 100%; padding: 12px 14px; border: 1px solid rgba(255,255,255,.18); background: rgba(255,255,255,.06);
                color: var(--text); border-radius: 12px; outline: none; }
        input::placeholder { color: #9aa5b1; }
        button { padding: 12px 16px; border:0; border-radius:12px; background: #111827; color: #fff; cursor: pointer; }
        .result { margin-top: 14px; padding: 14px; border-radius: 14px; background: rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08) }
        table { width:100%; border-collapse: collapse; }
        th, td { padding: 10px; border-bottom: 1px solid rgba(255,255,255,.08); text-align:left; }
        tr:hover { background: rgba(255,255,255,.04); }
        .link { color:#fff; text-decoration: underline; cursor:pointer; }
        .muted { color: var(--muted); font-size: 13px; }
        .risk { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; }
        .bar { height: 14px; border-radius: 8px; background: rgba(255,255,255,.08); overflow: hidden; }
        .bar > div { height: 100%; background: linear-gradient(90deg, var(--acc), var(--acc2)); }
        .tag { display:inline-block; padding: 4px 10px; border-radius: 999px; font-size:12px; background: rgba(96,165,250,.12); color:#c7d2fe; border:1px solid rgba(96,165,250,.35); }
        .row-opts { display:flex; gap:12px; align-items:center; margin-top:10px; flex-wrap:wrap; }
        select { padding: 8px 10px; border-radius: 8px; background: rgba(255,255,255,.06); color: var(--text); border:1px solid rgba(255,255,255,.18); }
      </style>
    </head>
    <body>
      <div class="wrap">
        <h1>전세사기 위험도 예측</h1>
        <div class="subtitle">보유 CSV에서 <b>주소로 검색</b>하고, 선택 샘플의 <b>밀도 기반 위험도</b>를 보여줍니다. (기본: density)</div>

        <div class="grid">
          <div class="card">
            <h3>주소 검색</h3>
            <p class="muted">2자 이상 입력하세요. (예: 중구 동호로, 성원빌라)</p>
            <div class="row">
              <input id="q" placeholder="주소 키워드" />
              <button onclick="searchAddr()">검색</button>
            </div>
            <div class="row-opts">
              <label class="muted">방법</label>
              <select id="method">
                <option value="density" selected>density</option>
                <option value="posterior">posterior</option>
                <option value="mahal">mahal</option>
                <option value="mixture">mixture</option>
                <option value="hybrid">hybrid</option>
              </select>
              <label class="muted">beta(유사도)</label>
              <input id="beta" type="number" step="0.1" value="1.2" style="width:90px"/>
              <label class="muted">lam(하이브리드)</label>
              <input id="lam" type="number" step="0.1" value="0.4" style="width:90px"/>
            </div>
            <div id="searchOut" class="result" style="display:none"></div>
          </div>

          <div class="card">
            <h3>선택 샘플 예측</h3>
            <div id="predOut" class="result" style="display:none"></div>
            <p class="muted">※ density = 1 - minmax(p(x)); 밀도가 낮을수록 위험↑</p>
          </div>
        </div>
      </div>

      <script>
        async function searchAddr() {
          const q = document.getElementById('q').value.trim();
          const out = document.getElementById('searchOut');
          if (q.length < 2) { out.style.display='block'; out.innerHTML='검색어를 2자 이상 입력하세요.'; return; }
          out.style.display='block'; out.innerHTML='검색 중...';
          const res = await fetch('/search?query=' + encodeURIComponent(q));
          if (!res.ok) { out.innerHTML='검색 실패'; return; }
          const data = await res.json();
          if (!data.results || data.results.length === 0) { out.innerHTML='결과 없음'; return; }
          let rows = '';
          for (const r of data.results) {
            rows += '<tr>' +
                    '<td>' + r.id + '</td>' +
                    '<td>' + r.addr + '</td>' +
                    '<td><span class="link" onclick="predictById(\\'' + r.id + '\\')">위험도</span></td>' +
                    '</tr>';
          }
          out.innerHTML = '<table>' +
            '<thead><tr><th style="width:120px">ID</th><th>주소</th><th style="width:100px">예측</th></tr></thead>' +
            '<tbody>' + rows + '</tbody>' +
          '</table>';
        }

        async function predictById(id) {
          const box = document.getElementById('predOut');
          box.style.display='block';
          box.innerHTML='예측 중...';

          const method = document.getElementById('method').value;
          const beta = document.getElementById('beta').value || '1.2';
          const lam = document.getElementById('lam').value || '0.4';

          const url = '/predict_by_id?id=' + encodeURIComponent(id) +
                      '&method=' + encodeURIComponent(method) +
                      '&beta=' + encodeURIComponent(beta) +
                      '&lam=' + encodeURIComponent(lam);
          const res = await fetch(url);
          if (!res.ok) {
            let msg = '예측 실패';
            try { const j = await res.json(); msg += ' — ' + (j.detail || JSON.stringify(j)); } catch(e) {}
            box.innerHTML = msg; return;
          }
          const data = await res.json();
          renderPrediction(box, data);
          window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
        }

        function renderPrediction(container, data) {
          const risk = Math.max(0, Math.min(1, Number(data.risk || 0)));
          const pct = (risk * 100).toFixed(1);
          const bucket = risk < 0.33 ? "낮음" : (risk < 0.66 ? "보통" : "높음");
          container.innerHTML =
            '<div class="risk">' +
              '<div><strong>위험도</strong> ' + pct + '%</div>' +
              '<span class="tag">' + bucket + '</span>' +
            '</div>' +
            '<div class="bar"><div style="width:' + pct + '%"></div></div>' +
            '<div class="muted" style="margin-top:8px">method=' + data.method +
              ', beta=' + data.beta + ', lam=' + data.lam + '</div>';
        }
      </script>
    </body>
    </html>
    """
    return HTMLResponse(html)

@app.get("/search")
def search(query: str = Query(..., min_length=2, description="주소 키워드"), limit: int = 20):
    q = query.strip().lower()
    hits = _df[_df["__addr_lc"].str.contains(q, na=False)].head(limit)
    rows: List[Dict[str, Any]] = []
    for _, r in hits.iterrows():
        rows.append({"id": str(r.get(COL_ID, "")), "addr": str(r.get("address_disp", ""))})
    return {"count": len(rows), "results": rows}

@app.get("/predict_by_id")
def predict_by_id(
    id: str = Query(...),
    method: str = Query("density", regex="^(density|posterior|mahal|mixture|hybrid)$"),
    beta: float = Query(1.2, ge=0.1, le=5.0),
    lam: float = Query(0.4, ge=0.0, le=1.0),
    high_idx: int = Query(HIGH_RISK, ge=0)
):
    rows = _df[_df[COL_ID].astype(str) == str(id)]
    if rows.empty:
        raise HTTPException(404, detail="ID에 해당하는 샘플이 없습니다.")
    row = rows.iloc[0]

    # 입력 1행 DF 만들고 스케일 → Z
    try:
        X1 = pd.DataFrame([{c: row.get(c) for c in FEATURES}], columns=FEATURES)
        X1_num = _ensure_feats_df(X1, FEATURES)
        Z = _transform(X1_num)
    except Exception as e:
        raise HTTPException(500, detail=f"입력/전처리 실패: {e}")

    try:
        if method == "density":
            risk = float(density_risk(Z)[0])
        elif method == "posterior":
            risk = float(posterior_risk(Z, high_idx=high_idx)[0])
        elif method == "mahal":
            risk = float(mahal_risk(Z, high_idx=high_idx)[0])
        elif method == "mixture":
            risk = float(mixture_similarity_risk(Z, beta=beta, high_idx=high_idx)[0])
        else:  # hybrid
            risk = float(hybrid_risk(Z, beta=beta, lam=lam, high_idx=high_idx)[0])
    except Exception as e:
        raise HTTPException(500, detail=f"예측 실패: {e}")

    return {"id": str(row.get(COL_ID, "")), "risk": risk, "method": method, "beta": beta, "lam": lam, "high_idx": high_idx}

@app.get("/diag")
def diag(id: str = Query(...)):
    rows = _df[_df[COL_ID].astype(str) == str(id)]
    if rows.empty:
        raise HTTPException(404, detail="ID가 없습니다.")
    row = rows.iloc[0]
    X1 = pd.DataFrame([{c: row.get(c) for c in FEATURES}], columns=FEATURES)
    X1_num = _ensure_feats_df(X1, FEATURES)
    Z = _transform(X1_num)
    logp = _gmm.score_samples(Z)[0]
    dens = float(np.exp(logp))
    return {
        "id": str(row.get(COL_ID, "")),
        "features": FEATURES,
        "raw": {c: row.get(c) for c in FEATURES},
        "numeric": {c: float(X1_num.iloc[0][c]) for c in FEATURES},
        "Z": Z[0].tolist(),
        "logp": float(logp),
        "dens": dens,
        "scale_p1": DENS_P1,
        "scale_p99": DENS_P99,
    }

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("app:app", host="0.0.0.0", port=port)
